from collections.abc import Generator

from sqlalchemy.orm import Session, sessionmaker

from app.infrastructure.database.connection import engine


Session_local = sessionmaker(
    bind=engine, 
    class_=Session,
    autocommit=False, 
    autoflush=False, 
    expire_on_commit=False,
)

def get_db() -> Generator[Session, None, None]:
    db = Session_local()
    try:
        yield db
    finally:
        db.close()